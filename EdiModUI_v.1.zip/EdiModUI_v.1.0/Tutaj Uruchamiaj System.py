#
#███████╗██████╗ ██╗███╗   ███╗ ██████╗ ██████╗ ██╗   ██╗██╗            @ @@@@@
#██╔════╝██╔══██╗██║████╗ ████║██╔═══██╗██╔══██╗██║   ██║██║                  @
#█████╗  ██║  ██║██║██╔████╔██║██║   ██║██║  ██║██║   ██║██║            @  @  @
#██╔══╝  ██║  ██║██║██║╚██╔╝██║██║   ██║██║  ██║╚██╗ ██╔╝██║            @
#███████╗██████╔╝██║██║ ╚═╝ ██║╚██████╔╝██████╔╝ ╚████╔╝ ██║            @@@@@ @
#╚══════╝╚═════╝ ╚═╝╚═╝     ╚═╝ ╚═════╝  ╚═════╝  ╚═══╝  ╚═╝           
# ------------------------------------------------------------------------    version(wersia):1.0
#  ██████╗ █████╗ ██████╗ ██╗   ██╗ █████╗  ██╗  █████╗ ██╗  ██╗████████╗
#██╔════╝██╔═══██║██╔══██╗╚██╗ ██╔╝ ██╔══██╗██║██╔════╝ ██║  ██║╚══██╔══╝
#██║     ██║   ██║██████╔╝ ╚████╔╝  ██████╔╝██║██║ ███╗ ███████║   ██║   
#██║     ██║   ██║██╔═══╝   ╚██╔╝   ██╔══██╗██║██║  ██║ ██╔══██║   ██║   
#╚██████╗╚██████╔╝██║        ██║    ██   ██║██ ███████║ ██   ██║   ██║
# ╚═════╝ ╚═════╝ ╚═╝        ╚═╝    ╚═════╝ ╚═╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝
#                       ██████╗ ██╗   ██╗
#                       ██╔══██╗╚██╗ ██╔╝
#                       ██████╔╝ ╚████╔╝ 
#                       ██╔══██╗  ╚██╔╝  
#                       ██████╔╝   ██║   
#                       ╚═════╝    ╚═╝   
#███████╗██████╗ ██╗███╗   ███╗ ██████╗ ██████╗ 
#██╔════╝██╔══██╗██║████╗ ████║██╔═══██╗██╔══██╗
#█████╗  ██║  ██║██║██╔████╔██║██║   ██║██║  ██║
#██╔══╝  ██║  ██║██║██║╚██╔╝██║██║   ██║██║  ██║
#███████╗██████╔╝██║██║ ╚═╝ ██║╚██████╔╝██████╔╝
#╚══════╝╚═════╝ ╚═╝╚═╝     ╚═╝ ╚═════╝ ╚═════╝         (c)2026 wszelkie prawa zastrzerzone









import os
import time
import sys
import termios
import tty
import select


skip = False


def check_key():
    global skip

    if select.select([sys.stdin], [], [], 0)[0]:
        key = sys.stdin.read(1)

        if key.lower() == "r":
            skip = True


def skipable_sleep(seconds):
    global skip

    start = time.time()

    while time.time() - start < seconds:
        check_key()

        if skip:
            return True

        time.sleep(0.05)

    return False


def loading(text, seconds=7):
    global skip

    print(text)

    if skip:
        print(" SKIPPED")
        return

    krok = 30
    delay = seconds / krok

    for i in range(krok):
        check_key()

        if skip:
            print(" SKIPPED")
            return

        sys.stdout.write("━")
        sys.stdout.flush()
        time.sleep(delay)

    print(" 100%")


def ok(text):
    global skip

    if skip:
        return

    time.sleep(0.5)
    print(f"[  OK  ] {text}")


# tryb odczytu klawiszy
old_settings = termios.tcgetattr(sys.stdin)
tty.setcbreak(sys.stdin.fileno())


try:

    print("""
███████╗██████╗ ██╗███╗   ███╗ ██████╗ ██████╗ ██╗   ██╗██╗             @ @@@@@
██╔════╝██╔══██╗██║████╗ ████║██╔═══██╗██╔══██╗██║   ██║██║                   @
█████╗  ██║  ██║██║██╔████╔██║██║   ██║██║  ██║██║   ██║██║             @  @  @
██╔══╝  ██║  ██║██║██║╚██╔╝██║██║   ██║██║  ██║╚██╗ ██╔╝██║             @     
███████╗██████╔╝██║██║ ╚═╝ ██║╚██████╔╝██████╔╝ ╚████╔╝ ██║             @@@@@ @             
╚══════╝╚═════╝ ╚═╝╚═╝     ╚═╝ ╚═════╝  ╚═════╝  ╚═══╝  ╚═╝     v.1.0
""")

    print("Press R to skip boot")

    skipable_sleep(4)

    time.sleep(3)
    print("Kernel:5.19-generic")
    print("Shell:bash 5.2")
    print("Terminal:console")
    print("CPU:Intel core 2 duo E8400")
    print("")

    time.sleep(2)
    loading("Loading Boot.img (14.0 MB)", 0)
    ok("Checking system files")

    time.sleep(2)
    loading("Starting Kernel", 2)
    ok("Kernel loaded")

    time.sleep(3)
    loading("Starting bash 5.2", 3)
    ok("Shell ready")

    time.sleep(1)
    loading("Loading User Interface", 2)
    ok("Console")

    time.sleep(2)
    loading("Loading EdiModUI", 1)
    ok("EdiModUI started")

    loading("/bin/", 0.3)
    ok("Mounted /bin")

    loading("/dev/", 0.3)
    ok("Mounted /dev")

    loading("/etc/", 0.5)
    ok("Loaded configuration")

    loading("/home/", 0.5)
    ok("Loaded users")

    loading("/lib/", 0.7)
    ok("Loaded libraries")

    time.sleep(2)
    loading("/usr/", 1)
    ok("Loaded programs")

    loading("/var/", 0.5)
    ok("Loaded logs")

    loading("/proc/", 0.3)
    ok("Mounted filesystem")


finally:
    termios.tcsetattr(
        sys.stdin,
        termios.TCSADRAIN,
        old_settings
    )

time.sleep(3)
print("User@Localhost:~/EdiModUI$")
time.sleep(5)

time.sleep(2)
os.system("cls" if os.name == "nt" else "clear")
#koniec aminacji
#koniec aminacji
#koniec aminacji
print("Loading...")
time.sleep(3)
print("Copyright Edimod Corporation. Wszelkie prawa zastrzeżone.")
print("!WAIT AND READ!")
time.sleep(5)
os.system("cls" if os.name == "nt" else "clear")
#
#Gotowy zaladowany system
#
print("EdiModUI V.1.0")
print("type help for Commands")


#pozwala na -bash "cośtam" command not found lepiej nie tykaj
while True:
    surowa_komenda = input("User@Localhost:~/EdiModUI$ ").strip()
    komenda = surowa_komenda.lower()

#Minecraft
    if komenda == "minecraft":
        print("Minecraft for EdiModUI...")
        print("GitHub: https://github.com/Skile109")
        print("Copyringht (c) 2026 Skile109")
        print("Uruchamianie za 8 sekund...")
        
        # PRZYWRÓCENIE USTAWIEN TERMINALA DLA URSINY:
        try:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
        except Exception:
            pass

        time.sleep(2) # zredukowano czas oczekiwania
        import Minecraft

#kolko i krzyrzyk
    elif komenda == "tictactoe":
        print("Starting EdiMod TicTacToe...")
        import tictactoe
        tictactoe.main()

#tetris
    elif komenda == "tetris":
        print("Starting EdiMod Tetris...")

        try:
            termios.tcsetattr(
                sys.stdin,
                termios.TCSADRAIN,
                old_settings
            )
        except Exception:
            pass

        import tetris
        tetris.main()
    
#help    
    if komenda == "help":
        print("EdiMod Shell, version 1.0")
        print("These commands are built into the shell.")
        print("Type 'help <command>' to get more information.\n")
        print("")
        print("neofetch-Display system information")
        print("inecraft     -Start Minecraft")
        print("crash     -Simulate a system crash")
        print("ls     -List available files")
        print("sudo     -sudo command")
        print("exit     -Exit the shell")
        print("tetris")
        print("tictactoe")
        print("copyringht")

#copyringht
    elif komenda == "copyright":
        print("Copyright Edimod Corporation.")
        print("Wszelkie prawa zastrzeżone")
        print("Github:https://github.com/edimod95")
        print("Github2:https://github.com/Skile109")

#sudo
    elif komenda == "sudo":
        print("user is not in sudoers")

#ls
    elif komenda == "ls":
        print("EdiModUI.py EdiMod.py pi-apps ")
        print("lib bin etc share videos")

#crash
    elif komenda == "crash":
        print("        .--.")
        print("       |o_o |")
        print("       |:_/ |")
        print("      //   \\ \\")
        print("     (|     | )")
        print("    /'\\_   _/`\\")
        print("    \\___)=(___/")
        print("")
        print("          !")
        print("   KERNEL PANIC")
        print("")
        print("Kernel: 5.19-generic")
        print("Reason: Fatal error")
        print("System halted.")

#neofetch        
    elif komenda == "neofetch":
        print("@@ @@@@@@@@@@@    User@Localhost")
        print("@@ @@@@@@@@@@@    ----------------")
        print("            @@    Host:Python VM")
        print("      @@    @@    OS:EdiModUI")
        print("@@    @@          Kernel:5.19-generic:")
        print("@@                Uptime: Unknown")
        print("@@@@@@@@@@  @@    Shell:bash 5.2")
        print("@@@@@@@@@@  @@    Terminal:console")
        print("                  CPU:Intel core 2 duo E8400")

#exit
    elif komenda == "exit":
        print("Zamykanie programu...")
        break

    else:
        print(f"-bash {surowa_komenda} command not found")
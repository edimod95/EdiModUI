EdiModUI 1.0
System Operacyjny
----------------------
Kod wykozystuje Phyton PyGame oraz Ursine
nie zbędne do działańia
Zainstaluj Programy!
Phyton:Kliknij Rozszzerzenia i zainstaluj Phyton
PyGame W terminalu:pip install pygame
Ursina:pip3 install ursina
----------------------
System obsługuje język programowania "Python"
więcej o pythonie na https://www.python.org
----------------------
Błędy proszę zgłośić na edimod95@gmail.com
------------------------------------------------------------------
Copyringht EdiMod Studio Code 2026(c)

@ @@@@@    Username:User
      @    Host:Phyton VM
@  @  @    OS:EdiModUI
@          Kernel:1.0-generic
@@@@@ @    Uptime:Error:
           Pacages:3
           Shell:-Winba 1.0
           Terminal:console
           CPU:Intel core 2 duo E8400
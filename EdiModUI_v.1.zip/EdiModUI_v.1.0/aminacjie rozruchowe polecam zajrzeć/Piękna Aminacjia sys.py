import time
import sys

def loading(text, seconds=7):
    print(text)
    krok = 30
    delay = seconds / krok

    for i in range(krok):
        sys.stdout.write("━")
        sys.stdout.flush()
        time.sleep(delay)

    print(" 100%")

def ok(text):
    time.sleep(0.5)
    print(f"[  OK  ] {text}")

print("""
███████╗██████╗ ██╗███╗   ███╗ ██████╗ ██████╗ ██╗   ██╗██╗
██╔════╝██╔══██╗██║████╗ ████║██╔═══██╗██╔══██╗██║   ██║██║
█████╗  ██║  ██║██║██╔████╔██║██║   ██║██║  ██║██║   ██║██║
██╔══╝  ██║  ██║██║██║╚██╔╝██║██║   ██║██║  ██║╚██╗ ██╔╝██║
███████╗██████╔╝██║██║ ╚═╝ ██║╚██████╔╝██████╔╝ ╚████╔╝ ██║
╚══════╝╚═════╝ ╚═╝╚═╝     ╚═╝ ╚═════╝ ╚═════╝  ╚═══╝  ╚═╝
""")

# czas na logo EdiMod
time.sleep(4)

print("EdiModUI Boot System 1.0")
print("Kernel: 5.19-generic")
print("Shell: bash 5.2")
print("")

loading("Loading Boot.img (14.0 MB)", 8)
ok("Checking system files")

loading("Starting Kernel", 7)
ok("Kernel loaded")

loading("Starting bash 5.2", 6)
ok("Shell ready")

loading("Loading User Interface", 10)
ok("EdiModUI started")

print("")
print("User@Localhost:~/EdiModUI$ ", end="")
import pygame
import random


WIDTH = 300
HEIGHT = 600
BLOCK = 30


COLORS = [
    (0, 255, 255),
    (0, 0, 255),
    (255, 165, 0),
    (255, 255, 0),
    (0, 255, 0),
    (160, 0, 160),
    (255, 0, 0)
]


SHAPES = [
    [[1,1,1,1]],

    [[1,1,1],
     [0,1,0]],

    [[1,1],
     [1,1]],

    [[1,0,0],
     [1,1,1]],

    [[0,0,1],
     [1,1,1]],

    [[0,1,1],
     [1,1,0]],

    [[1,1,0],
     [0,1,1]]
]


def new_piece():
    return {
        "shape": random.choice(SHAPES),
        "x": 3,
        "y": 0,
        "color": random.choice(COLORS)
    }


def rotate(piece):
    piece["shape"] = [
        list(x)
        for x in zip(*piece["shape"][::-1])
    ]


def valid(piece, board):

    for y,row in enumerate(piece["shape"]):
        for x,value in enumerate(row):

            if value:

                nx = piece["x"] + x
                ny = piece["y"] + y

                if nx < 0 or nx >= 10 or ny >= 20:
                    return False

                if ny >= 0 and board[ny][nx]:
                    return False

    return True


def clear_lines(board):

    new_board = []

    for row in board:

        if all(row):
            continue

        new_board.append(row)


    while len(new_board) < 20:
        new_board.insert(0,[0]*10)


    return new_board



def draw(screen, board, piece, font, score):

    for y in range(20):
        for x in range(10):

            if board[y][x]:

                pygame.draw.rect(
                    screen,
                    board[y][x],
                    (
                        x*BLOCK,
                        y*BLOCK,
                        BLOCK,
                        BLOCK
                    )
                )


    for y,row in enumerate(piece["shape"]):

        for x,value in enumerate(row):

            if value:

                pygame.draw.rect(
                    screen,
                    piece["color"],
                    (
                        (piece["x"]+x)*BLOCK,
                        (piece["y"]+y)*BLOCK,
                        BLOCK,
                        BLOCK
                    )
                )


    text = font.render(
        "Score: "+str(score),
        True,
        (255,255,255)
    )

    screen.blit(text,(5,5))



def main():

    pygame.init()

    screen = pygame.display.set_mode(
        (WIDTH,HEIGHT)
    )

    pygame.display.set_caption(
        "EdiMod Tetris"
    )


    clock = pygame.time.Clock()

    font = pygame.font.SysFont(
        None,
        30
    )


    board = [
        [0 for x in range(10)]
        for y in range(20)
    ]


    piece = new_piece()

    score = 0

    fall = 0
    speed = 500


    running = True


    while running:

        screen.fill(
            (15,15,15)
        )


        fall += clock.get_time()

        clock.tick(60)


        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False


            if event.type == pygame.KEYDOWN:


                if event.key == pygame.K_LEFT:

                    piece["x"] -= 1

                    if not valid(piece,board):
                        piece["x"] += 1


                if event.key == pygame.K_RIGHT:

                    piece["x"] += 1

                    if not valid(piece,board):
                        piece["x"] -= 1



                if event.key == pygame.K_UP:

                    rotate(piece)

                    if not valid(piece,board):

                        rotate(piece)
                        rotate(piece)
                        rotate(piece)



        if fall > speed:

            piece["y"] += 1
            fall = 0


            if not valid(piece,board):

                piece["y"] -= 1


                for y,row in enumerate(piece["shape"]):

                    for x,value in enumerate(row):

                        if value:

                            board[
                                piece["y"]+y
                            ][
                                piece["x"]+x
                            ] = piece["color"]


                old = len([r for r in board if all(r)])

                board = clear_lines(board)

                new = len([r for r in board if all(r)])

                score += (old-new)*100


                piece = new_piece()


                if not valid(piece,board):
                    running=False



        keys = pygame.key.get_pressed()

        if keys[pygame.K_DOWN]:
            speed = 80
        else:
            speed = 500



        draw(
            screen,
            board,
            piece,
            font,
            score
        )


        pygame.display.update()


    pygame.quit()



if __name__ == "__main__":
    main()
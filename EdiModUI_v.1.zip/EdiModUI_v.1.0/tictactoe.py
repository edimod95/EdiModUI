import pygame
import sys

pygame.init()

WIDTH = 600
HEIGHT = 600

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("EdiMod Kółko i Krzyżyk")

clock = pygame.time.Clock()

WHITE = (240,240,240)
BLACK = (0,0,0)
BLUE = (0,100,255)
RED = (255,0,0)

font = pygame.font.SysFont(None,100)
big_font = pygame.font.SysFont(None,60)


board = [
    ["","",""],
    ["","",""],
    ["","",""]
]


player = "X"
game_over = False


def draw():

    screen.fill(WHITE)


    # linie planszy
    pygame.draw.line(screen,BLACK,(200,0),(200,600),5)
    pygame.draw.line(screen,BLACK,(400,0),(400,600),5)

    pygame.draw.line(screen,BLACK,(0,200),(600,200),5)
    pygame.draw.line(screen,BLACK,(0,400),(600,400),5)


    # znaki
    for y in range(3):
        for x in range(3):

            if board[y][x] != "":

                color = BLUE

                if board[y][x] == "O":
                    color = RED


                text = font.render(
                    board[y][x],
                    True,
                    color
                )


                screen.blit(
                    text,
                    (
                        x*200+65,
                        y*200+45
                    )
                )



def check_win():

    # rzędy
    for row in board:
        if row[0] == row[1] == row[2] != "":
            return row[0]


    # kolumny
    for x in range(3):

        if board[0][x] == board[1][x] == board[2][x] != "":
            return board[0][x]


    # przekątne

    if board[0][0] == board[1][1] == board[2][2] != "":
        return board[0][0]


    if board[0][2] == board[1][1] == board[2][0] != "":
        return board[0][2]


    # remis

    full = True

    for row in board:
        for cell in row:
            if cell == "":
                full = False


    if full:
        return "REMIS"


    return None



def reset():

    global board
    global player
    global game_over


    board = [
        ["","",""],
        ["","",""],
        ["","",""]
    ]

    player = "X"
    game_over = False



def main():

    global player
    global game_over


    while True:

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()


            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_r:
                    reset()



            if event.type == pygame.MOUSEBUTTONDOWN:

                if not game_over:

                    mx,my = pygame.mouse.get_pos()

                    x = mx//200
                    y = my//200


                    if board[y][x] == "":

                        board[y][x] = player


                        winner = check_win()


                        if winner:
                            game_over = True


                        else:

                            if player == "X":
                                player = "O"
                            else:
                                player = "X"



        draw()


        if game_over:

            winner = check_win()

            text = big_font.render(
                winner + " WYGRYWA!",
                True,
                BLACK
            )

            screen.blit(
                text,
                (100,250)
            )


        pygame.display.update()

        clock.tick(60)



if __name__ == "__main__":
    main()
print("Uruchamianie Minecraft for EdiModUI...")

from ursina import (
    Ursina,
    Button,
    color,
    scene,
    mouse,
    destroy,
    Entity,
    camera,
    DirectionalLight,
    Vec3,
    Text,
    Texture,
    held_keys,
    time
)
from ursina.prefabs.first_person_controller import FirstPersonController

import random
import math

app = Ursina()

Texture.default_filtering = 'nearest'

obecny_blok = 1

TEKSTURY_BLOKOW = {
    1: 'trawa',
    2: 'kamien',
    3: 'drewno'
}

class Voxel(Button):
    def __init__(self, position=(0,0,0), blok_type=1):
        super().__init__(
            parent=scene,
            position=position,
            model='cube',
            origin_y=0.5,
            texture=TEKSTURY_BLOKOW.get(blok_type, 'white_cube'),
            color=color.white,
            highlight_color=color.lime
        )
        self.blok_type = blok_type

    def input(self, key):
        if self.hovered:
            if key == 'left mouse down':
                Voxel(
                    position=self.position + mouse.normal,
                    blok_type=obecny_blok
                )
            if key == 'right mouse down':
                destroy(self)

lista_mobow = []

class HumanMob(Entity):
    def __init__(self, position=(5, 1, 5)):
        super().__init__(
            parent=scene,
            position=position,
            model='cube',
            scale=(1, 2, 1),
            color=color.azure,
            origin_y=-0.5
        )

        self.glowa = Entity(
            parent=self,
            model='cube',
            scale=(1, 0.5, 1),
            y=1.2,
            color=color.peach
        )

        self.reka_lewa = Entity(
            parent=self,
            model='cube',
            scale=(0.2, 1, 0.2),
            x=-0.6,
            y=0.5,
            color=color.blue
        )

        self.reka_prawa = Entity(
            parent=self,
            model='cube',
            scale=(0.2, 1, 0.2),
            x=0.6,
            y=0.5,
            color=color.blue
        )

        self.kierunek = Vec3(0,0,0)
        self.czas_do_zmiany = 0
        self.predkosc = 2
        self.czas_animacji = 0
        self.zywotnosc = 60

        lista_mobow.append(self)

    def update(self):
        self.zywotnosc -= time.dt

        if self.zywotnosc <= 0:
            if self in lista_mobow:
                lista_mobow.remove(self)
            destroy(self)
            return

        self.czas_do_zmiany -= time.dt

        if self.czas_do_zmiany <= 0:
            kat = random.uniform(0, 360)
            self.rotation_y = kat
            rad = math.radians(kat)
            self.kierunek = Vec3(
                math.sin(rad),
                0,
                math.cos(rad)
            )
            self.czas_do_zmiany = random.uniform(1, 3)

        self.position += self.kierunek * self.predkosc * time.dt
        self.czas_animacji += time.dt * 10
        self.reka_lewa.rotation_x = math.sin(self.czas_animacji) * 60
        self.reka_prawa.rotation_x = -math.sin(self.czas_animacji) * 60

# ŚWIATŁO
slonce = DirectionalLight(
    parent=scene,
    y=10,
    z=-10,
    shadows=True
)
slonce.look_at(Vec3(0, 0, 0))

# GENEROWANIE MAPY
for z in range(20):
    for x in range(20):
        Voxel(
            position=(x, 0, z),
            blok_type=1
        )

# NIEWIDZIALNA PODŁOGA ASEKURACYJNA (zapobiega wpadaniu pod mapę)
podloga_asekuracyjna = Entity(
    model='plane',
    scale=(50, 1, 50),
    position=(10, -0.1, 10),
    collider='box',
    visible=False
)

# MOB STARTOWY
HumanMob(position=(10, 1, 10))

# NAPIS FPS
napis_wersji = Text(
    text="Minecraft Alpha 1.0 for EdiModUI\nFPS: 0",
    position=(-0.85, 0.48),
    scale=1.5,
    color=color.white
)

# PANEL INSTRUKCJI
instrukcja_tlo = Entity(
    parent=camera.ui,
    model="quad",
    scale=(0.4, 0.25),
    position=(0.65, 0.35),
    color=color.black66
)

instrukcja_tekst = Text(
    parent=instrukcja_tlo,
    text=
        "STEROWANIE:\n"
        "WSAD - Ruch\n"
        "Spacja - Skok\n"
        "LPM - Postaw blok\n"
        "PPM - Usun blok\n"
        "1,2,3 - Bloki\n"
        "G - Spawn Human\n"
        "R - Teleport",
    position=(-0.48, 0.45),
    scale=2.2,
    color=color.white
)

# HOTBAR
hotbar_tlo = Entity(
    parent=camera.ui,
    model="quad",
    scale=(0.4, 0.1),
    position=(0, -0.42),
    color=color.black66
)

slot1 = Entity(
    parent=hotbar_tlo,
    model="quad",
    scale=(0.2, 0.7),
    position=(-0.3, 0),
    color=color.green
)

slot2 = Entity(
    parent=hotbar_tlo,
    model="quad",
    scale=(0.2, 0.7),
    position=(0, 0),
    color=color.dark_gray
)

slot3 = Entity(
    parent=hotbar_tlo,
    model="quad",
    scale=(0.2, 0.7),
    position=(0.3, 0),
    color=color.brown
)

wybor_ramka = Entity(
    parent=hotbar_tlo,
    model="quad",
    scale=(0.24, 0.84),
    position=(-0.3, 0),
    color=color.rgba(1, 0, 0, 0.5)
)

# GRACZ
gracz = FirstPersonController()
gracz.position = (10, 5, 10)

# STAN PRZYCISKÓW
g_wcisniete = False
r_wcisniete = False

def update():
    global obecny_blok
    global g_wcisniete
    global r_wcisniete

    # Obroty słońca
    slonce.rotation_x += 0.05

    # FPS
    fps = int(1 / time.dt) if time.dt > 0 else 0
    napis_wersji.text = (
        f"Minecraft Alpha 1.0 for EdiModUI\n"
        f"FPS: {fps}"
    )

    # Wybór bloków
    if held_keys['1']:
        obecny_blok = 1
        wybor_ramka.position = (-0.3, 0)
    elif held_keys['2']:
        obecny_blok = 2
        wybor_ramka.position = (0, 0)
    elif held_keys['3']:
        obecny_blok = 3
        wybor_ramka.position = (0.3, 0)

    # Spawn Human (klawisz G)
    if held_keys['g']:
        if not g_wcisniete:
            HumanMob(
                position=(
                    random.uniform(2, 18),
                    2,
                    random.uniform(2, 18)
                )
            )
            g_wcisniete = True
    else:
        g_wcisniete = False

    # Teleport (klawisz R)
    if held_keys['r']:
        if not r_wcisniete:
            gracz.position = (
                random.uniform(2, 18),
                5,
                random.uniform(2, 18)
            )
            gracz.velocity = Vec3(0, 0, 0)  # Wyzerowanie pędu grawitacji
            r_wcisniete = True
    else:
        r_wcisniete = False

    # Respawn przy spadnięciu
    if gracz.y < -10:
        gracz.position = (10, 5, 10)
        gracz.velocity = Vec3(0, 0, 0)

# Uruchomienie pętli gry
app.run()

print("Minecraft został zamknięty.")
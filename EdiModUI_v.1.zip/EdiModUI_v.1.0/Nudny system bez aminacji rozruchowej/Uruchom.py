print("EdiModUI 1.0")
print("Copyright Edimod Corporation. Wszelkie prawa zastrzeżone.")
print("")
print("Help for Commands")

while True:
    komenda = input("user@Localhost:~/EdiModUI$ ").strip().lower()
    
    if komenda == "help":
        print("Type Minecraft For start Minecraft\nType neofetch for linux logo\nType fgjbkjal for ?")
        
    elif komenda == "neofetch":
        print("@ @@@@@    Username:User")
        print("      @    Host:Python VM")
        print("@  @  @    OS:EdiModUI")
        print("@          Kernel:5.19-generic")
        print("@@@@@ @    Uptime: Unknown:")
        print("           Shell:bash 5.2")
        print("           Terminal:console")
        print("           CPU:Intel core 2 duo E8400")

    elif komenda == "fgjbkjal":
            print("-bash fgjbkjal comannd not found")
     
        
    elif komenda == "minecraft":
        print("Uruchamianie Minecraft 3D z nowymi funkcjami...")
        
        from ursina import Ursina, Button, color, scene, mouse, destroy, Entity, camera, DirectionalLight, Vec3, Text
        from ursina.prefabs.first_person_controller import FirstPersonController
        import random  
        import math    
        
        app = Ursina()
        from ursina import Texture
        Texture.default_filtering = 'nearest' 
        
        obecny_blok = 1
        
        TEKSTURY_BLOKOW = {
            1: 'trawa',   
            2: 'kamien',  
            3: 'drewno'   
        }
        
        class Voxel(Button):
            def __init__(self, position=(0,0,0), blok_type=1):
                super().__init__(
                    parent=scene,
                    position=position,
                    model='cube',
                    origin_y=0.5,
                    texture=TEKSTURY_BLOKOW.get(blok_type, 'white_cube'),
                    color=color.white,
                    highlight_color=color.lime
                )
                self.blok_type = blok_type
            
            def input(self, key):
                if self.hovered:
                    if key == 'left mouse down':
                        Voxel(position=self.position + mouse.normal, blok_type=obecny_blok)
                    if key == 'right mouse down':
                        destroy(self)

        lista_mobow = []
                        
        class HumanMob(Entity):
            def __init__(self, position=(5, 1, 5)):
                super().__init__(
                    parent=scene,
                    position=position,
                    model='cube', 
                    scale=(1, 2, 1), 
                    color=color.azure,
                    origin_y=-0.5
                )
                self.glowa = Entity(parent=self, model='cube', scale=(1, 0.5, 1), y=1.2, color=color.peach)
                self.reka_lewa = Entity(parent=self, model='cube', scale=(0.2, 1, 0.2), x=-0.6, y=0.5, color=color.blue)
                self.reka_prawa = Entity(parent=self, model='cube', scale=(0.2, 1, 0.2), x=0.6, y=0.5, color=color.blue)
                
                self.kierunek = Vec3(0, 0, 0)
                self.czas_do_zmiany = 0
                self.predkosc = 2
                self.czas_animacji = 0
                self.zywotnosc = 60.0
                lista_mobow.append(self)

            def update(self):
                from ursina import time
                
                self.zywotnosc -= time.dt
                if self.zywotnosc <= 0:
                    if self in lista_mobow:
                        lista_mobow.remove(self)
                    destroy(self)
                    return

                if self.y < -20:
                    if self in lista_mobow:
                        lista_mobow.remove(self)
                    destroy(self)
                    return

                if self.x < -0.5 or self.x > 19.5 or self.z < -0.5 or self.z > 19.5:
                    self.y -= 9.8 * time.dt  
                    self.position += self.kierunek * self.predkosc * time.dt
                else:
                    self.czas_do_zmiany -= time.dt
                    if self.czas_do_zmiany <= 0:
                        kat = random.uniform(0, 360)
                        self.rotation_y = kat
                        rad = math.radians(kat)
                        self.kierunek = Vec3(math.sin(rad), 0, math.cos(rad))
                        self.czas_do_zmiany = random.uniform(1.0, 3.0) 

                    self.position += self.kierunek * self.predkosc * time.dt

                self.czas_animacji += time.dt * 15
                self.reka_lewa.rotation_x = math.sin(self.czas_animacji) * 60
                self.reka_prawa.rotation_x = -math.sin(self.czas_animacji) * 60

        slonce = DirectionalLight(parent=scene, y=10, z=-10, shadows=True)
        slonce.look_at(Vec3(0,0,0))
        
        for z in range(20):
            for x in range(20):
                Voxel(position=(x, 0, z), blok_type=1)
                
        HumanMob(position=(10, 1, 10))
                
        # Napis w lewym górnym rogu (Wersja + FPS)
        napis_wersji = Text(
            text='Minecraft Alpha 1.0 for EdiModUI\nFPS: 0',
            position=(-0.85, 0.48),
            scale=1.5,
            color=color.white
        )

        # ZMIANA: Tło instrukcji w prawym górnym rogu ekranu
        instrukcja_tlo = Entity(
            parent=camera.ui,
            model='quad',
            scale=(0.4, 0.25),
            position=(0.65, 0.35),
            color=color.black66
        )

        # ZMIANA: Tekst instrukcji ułożony linijka po linijce
        instrukcja_tekst = Text(
            parent=instrukcja_tlo,
            text='  STEROWANIE:\n'
                 '  WSAD - Ruch\n'
                 '  Spacja - Skok\n'
                 '  LPM - Postaw blok\n'
                 '  PPM - Usun blok\n'
                 '  1,2,3 - Wybor bloku\n'
                 '  G - Spawn Human\n'
                 '  R - Losowa TP',
            position=(-0.48, 0.45),
            scale=2.2,
            color=color.white
        )
                
        hotbar_tlo = Entity(parent=camera.ui, model='quad', scale=(0.4, 0.1), position=(0, -0.42), color=color.black66)
        slot1 = Entity(parent=hotbar_tlo, model='quad', scale=(0.2, 0.7), position=(-0.3, 0), color=color.green)
        slot2 = Entity(parent=hotbar_tlo, model='quad', scale=(0.2, 0.7), position=(0, 0), color=color.dark_gray)
        slot3 = Entity(parent=hotbar_tlo, model='quad', scale=(0.2, 0.7), position=(0.3, 0), color=color.brown)
        wybor_ramka = Entity(parent=hotbar_tlo, model='quad', scale=(0.24, 0.84), position=(-0.3, 0), color=color.rgba(1, 0, 0, 0.5))
        
        g_wcisniete = False
        r_wcisniete = False
        
        def update():
            global obecny_blok, g_wcisniete, r_wcisniete
            from ursina import held_keys, time
            slonce.rotation_x += 0.05
            
            aktualne_fps = int(1.0 / (time.dt if time.dt > 0 else 0.001))
            napis_wersji.text = f'Minecraft Alpha 1.0 for EdiModUI\nFPS: {aktualne_fps}'
            
            for mob in lista_mobow:
                odleglosc = math.sqrt((gracz.x - mob.x)**2 + (gracz.z - mob.z)**2)
                if odleglosc < 1.2 and abs(gracz.y - mob.y) < 2:
                    wektor_x = mob.x - gracz.x
                    wektor_z = mob.z - gracz.z
                    mianownik = math.sqrt(wektor_x**2 + wektor_z**2) if (wektor_x**2 + wektor_z**2) > 0 else 1
                    mob.x += (wektor_x / mianownik) * 0.5
                    mob.z += (wektor_z / mianownik) * 0.5
            
            if gracz.y < -30:
                gracz.position = (10, 5, 10)
            
            if held_keys['1']:
                obecny_blok = 1
                wybor_ramka.position = (-0.3, 0)
            elif held_keys['2']:
                obecny_blok = 2
                wybor_ramka.position = (0, 0)
            elif held_keys['3']:
                obecny_blok = 3
                wybor_ramka.position = (0.3, 0)
                
            if held_keys['g']:
                if not g_wcisniete:
                    losowe_x = random.uniform(2, 18)
                    losowe_z = random.uniform(2, 18)
                    HumanMob(position=(losowe_x, 1, losowe_z))
                    g_wcisniete = True
            else:
                g_wcisniete = False

            if held_keys['r']:
                if not r_wcisniete:
                    gracz.x = random.uniform(1, 19)
                    gracz.z = random.uniform(1, 19)
                    gracz.y = 3 
                    r_wcisniete = True
            else:
                r_wcisniete = False
                
        gracz = FirstPersonController()
        gracz.position = (10, 2, 10)
        app.run()
        
    elif komenda == "exit":
        print("Zamykanie programu...")
        break
